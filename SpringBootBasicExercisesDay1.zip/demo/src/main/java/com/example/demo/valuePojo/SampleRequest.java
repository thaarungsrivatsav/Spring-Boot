package com.example.demo.valuePojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SampleRequest {
    private String name;
    private String expertise;
}
