package com.example.demo.endpoint;

import com.example.demo.Service.DemoService;
import com.example.demo.valuePojo.SampleRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
/*
how to execute this file
run the file in the IDE -> then go to browser -> localhost:8080/hi
output: hello will be displayed there in the browser
 */

@RestController
//@RequestMapping(value = "/welcome")
public class demoendpoint {
    @Value("${server.company}")
    private String company;

    @RequestMapping(value = "/hi")
    public String hi() {
        return "hello";
    }

    @RequestMapping(value = "/hello")
    public String hey() {
        return "hello ".concat(company);
    }

    // check this output by giving http://localhost:8082/param?name=ganesh
    //request parameter passing with single value
    @RequestMapping(value = "/param")
    public String query(@RequestParam(value = "name") final String username) {
        return "hello ".concat(username);
    }

    // check this output by giving http://localhost:8082/paramMultiple?name=ganesh&company=expeditors
    //request parameter passing with Multiple values
    @RequestMapping(value = "/paramMultiple")
    public String multiplequery(@RequestParam(value = "name") final String username, @RequestParam(value = "company") final String company) {
        return "hello ".concat(username).concat(company);
    }

    @RequestMapping(value = "/gettersetter")
    public SampleRequest get(@RequestBody final SampleRequest sampleRequest) {
        System.out.println(sampleRequest.getName());
        System.out.println(sampleRequest.getExpertise());
        return sampleRequest;

    }

    @Autowired
    DemoService demoService;

    @GetMapping(value = "/both")
    public SampleRequest getSampleRequest(@RequestParam String name, @RequestParam String expertise) {
        return demoService.getSampleRequest(name, expertise);
    }

//    @RequestMapping(value = "/haai") this will throw error since one method is declared with same name
//    public String hi()
//    {
//        return "hello";
//    }

//        @RequestMapping(value = "/hi")this will throw error , coz one request mapping can be only used once
//        public String hi()
//        {
//            return "hello";
//        }


}
