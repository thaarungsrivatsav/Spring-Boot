package com.example.demo.Service;


import com.example.demo.valuePojo.SampleRequest;
import org.springframework.stereotype.Service;

@Service
public class DemoService {

    public SampleRequest getSampleRequest(String name, String expertise) {
        SampleRequest sampleRequest = new SampleRequest();
        sampleRequest.setName(name);
        sampleRequest.setExpertise(expertise);
        return sampleRequest;
    }
}

